﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BCrypt.Net;
using Microsoft.Extensions.Configuration;
using System.Linq;
using WebAPINatureHub3.Models;
using Microsoft.CodeAnalysis.Scripting;

namespace WebAPINatureHub3.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly NatureHub3Context _context;
        private readonly JwtService _jwtService;

        public AuthController(NatureHub3Context context, JwtService jwtService)
        {
            _context = context;
            _jwtService = jwtService;
        }

        // Admin Login
        [HttpPost("admin/login")]
        public IActionResult AdminLogin([FromBody] LoginRequest model)
        {
            var admin = _context.Admins.SingleOrDefault(a => a.Username == model.Username);
            if (admin == null)
            {
                return Unauthorized("Admin not found.");
            }

            if (!BCrypt.Net.BCrypt.Verify(model.Password, admin.Password))
            {
                return Unauthorized("Invalid password.");
            }

            var token = _jwtService.GenerateToken(admin.AdminId, "Admin");
            return Ok(new { token });
        }

        // User Signup
        [HttpPost("user/signup")]
        public IActionResult UserSignup([FromBody] SignupRequest model)
        {
            if (_context.Users.Any(u => u.Email == model.Email))
            {
                return BadRequest("Email already exists.");
            }

            var hashedPassword = BCrypt.Net.BCrypt.HashPassword(model.Password);  // Fixed typo here

            var user = new User
            {
                UserName = model.UserName,
                Email = model.Email,
                Password = hashedPassword,
                RoleId = 2 // Default to User role
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            return CreatedAtAction(nameof(UserLogin), new { email = model.Email });
        }

        // User Login
        [HttpPost("user/login")]
        public IActionResult UserLogin([FromBody] LoginRequest model)
        {
            var user = _context.Users.SingleOrDefault(u => u.Email == model.Email);
            if (user == null)
            {
                return Unauthorized("User not found.");
            }

            if (!BCrypt.Net.BCrypt.Verify(model.Password, user.Password))
            {
                return Unauthorized("Invalid password.");
            }

            var token = _jwtService.GenerateToken(user.UserId, "User");
            return Ok(new { token });
        }
    }

    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; } // Add Email for user login
    }

    public class SignupRequest
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
    }

    public class JwtService
    {
        private readonly IConfiguration _configuration;

        public JwtService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public string GenerateToken(int userId, string role)
        {
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, userId.ToString()),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.Role, role)
            };

            var secretKey = _configuration["JwtSecretKey"]; // Get secret key from appsettings
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: "https://localhost:44348",  // Replace with your actual issuer
                audience: "https://localhost:44348", // Replace with your actual audience
                claims: claims,
                expires: DateTime.UtcNow.AddHours(1), // Token expiration time
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
